Numbers look so much better on charts! This is an (updated) example of how to set graph properties in Access using VBA based on specified criteria such as dates and key fields.  The menu is called  f_Graph_MENU.  The form that shows the graph is f_Graph.  f_PopupCalendar is a for collecting dates (tiggered by double-clicking a date control).  The sample tables are called t_GraphData and t_GraphTopics.  The code creates the qGraph query used by the graph.  This was developed in 2010 using Microsoft Graph 14.0 Object Library, which does need to be referenced due to late binding.  If graph has no data, an error is generated.  This could be trapped.  SetControl_RowSource is used on the After Update of the topic to limit other combos.  This is done by putting the SQL without criteria in the Tag property of each respective combo.  

There is a form called f_Graph that has the Microsoft Graph control and a couple other controls that get modified.  The menu form is called f_Graph_Menu. The button that opens the graph is captioned "Chart".  The time frame can be changed from Days to Weeks to Months.  On the right are other properties such as Chart Title, format for X and Y axes, X-Axis Title, and Minimum and Maximum Scale for the Y-Axis. 

What makes the data work is modifying the SQL of the query that the graph is based on, qGraph. 

This example also illustrates the method I use to cascade comboboxes.  I put the SQL with no criteria in the Tag property of each respective combo then send the criteria and the control to a function I wrote called SetControl_RowSource, which is usually a public function.  This example, however, embeds it behind the form that uses it and declares it to be private. 

Double-click a date to popup a calendar form called f_PopupCalendar.  If a date OpenArg is sent to the form, it will set the calendar to that date and not store it.  This is done on the second date of the date range for cases when Date1 is specified but not Date2.  

Graph Example posted on MS_Access_Professionals, a Yahoo technical discussion group 
http://groups.yahoo.com/neo/groups/MS_Access_Professionals/files/Crystal/ 
and
http://www.AccessMVP.com/strive4peace/Access_Graphs.htm

Popup Calendar posted on Rogers Access Library 
http://www.RogersAccessLibrary.com/forum/popup-calendar-for-access-2007-and-above_topic597.html 

20-minute video tutorial on YouTube: 
Tool and Code: Graphs and Charts in Microsoft Access (cc) 
http://www.youtube.com/watch?v=Zc5WAPderyQ 

Warm Regards, 
Crystal 
strive4peace2008@yahoo.com 

Remote Programming & Training -- connect to me, let's built it together 

Through sharing, we will all get better 
~  have an awesome day ~ 

